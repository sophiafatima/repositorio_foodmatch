<div>
    <h2>Lista de Compras</h2>
    @if ($listas->count())
        @foreach ($listas as $lista)
            <div>
                <p>Receita ID: {{ $lista->id_receita }}</p>
                <p>Recomendação: {{ $lista->recomendacao }}</p>
                <p>Ingredientes: {{ $lista->ingredientes }}</p>
            </div>
        @endforeach
    @else
        <p>Nenhuma lista de compras encontrada.</p>
    @endif
</div>