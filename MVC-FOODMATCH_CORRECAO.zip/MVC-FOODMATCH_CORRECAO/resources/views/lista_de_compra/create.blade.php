<div>
    <form method="POST" action="{{ route('lista_de_compras.store') }}">
        @csrf
        <input name="id_receita" placeholder="ID da receita" />
        <input name="recomendacao" placeholder="Recomendação" />
        <textarea name="ingredientes" placeholder="Ingredientes"></textarea>
        <button type="submit">Criar lista</button>
    </form>
</div>