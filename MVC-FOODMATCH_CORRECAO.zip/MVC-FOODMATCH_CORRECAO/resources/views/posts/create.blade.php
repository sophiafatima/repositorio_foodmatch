<div>
<h2>Novo em Posts</h2>
<form action="/posts" method="POST">
@csrf
<label>id_usuario: <input name="id_usuario" /></label><br>
<label>titulo_post: <input name="titulo_post" /></label><br>
<label>descricao_post: <input name="descricao_post" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>