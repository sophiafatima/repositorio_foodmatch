<div>
<h2>Detalhe</h2>
@foreach($post->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/posts/{{ $post->getKey() }}/edit">Editar</a>
</div>