<div>
<h2>Editar</h2>
<form action="/posts/{{ $post->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>id_usuario: <input name="id_usuario" value="{{ old("id_usuario", $post->id_usuario ?? "") }}" /></label><br>
<label>titulo_post: <input name="titulo_post" value="{{ old("titulo_post", $post->titulo_post ?? "") }}" /></label><br>
<label>descricao_post: <input name="descricao_post" value="{{ old("descricao_post", $post->descricao_post ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/posts/{{ $post->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>