<div>
<h2>Posts</h2>
<a href="/posts/create">Criar</a>
<ul>
@foreach ($posts as $item)
<li><a href="/posts/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>