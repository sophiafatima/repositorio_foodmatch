<div>
<h2>Detalhe</h2>
@foreach($empresa->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/empresa/{{ $empresa->getKey() }}/edit">Editar</a>
</div>