<div>
<h2>Novo em Empresa</h2>
<form action="/empresa" method="POST">
@csrf
<label>nome_empresa: <input name="nome_empresa" /></label><br>
<label>email_empresa: <input name="email_empresa" /></label><br>
<label>senha_empresa: <input name="senha_empresa" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>