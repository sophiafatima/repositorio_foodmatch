<div>
<h2>Editar</h2>
<form action="/empresa/{{ $empresa->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>nome_empresa: <input name="nome_empresa" value="{{ old("nome_empresa", $empresa->nome_empresa ?? "") }}" /></label><br>
<label>email_empresa: <input name="email_empresa" value="{{ old("email_empresa", $empresa->email_empresa ?? "") }}" /></label><br>
<label>senha_empresa: <input name="senha_empresa" value="{{ old("senha_empresa", $empresa->senha_empresa ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/empresa/{{ $empresa->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>