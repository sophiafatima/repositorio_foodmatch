<div>
<h2>Empresa</h2>
<a href="/empresa/create">Criar</a>
<ul>
@foreach ($empresas as $item)
<li><a href="/empresa/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>