<div>
<h2>Detalhe</h2>
@foreach($user->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/users/{{ $user->getKey() }}/edit">Editar</a>
</div>