<div>
<h2>Novo em Users</h2>
<form action="/users" method="POST">
@csrf
<label>name: <input name="name" /></label><br>
<label>email: <input name="email" /></label><br>
<label>password: <input name="password" /></label><br>
<label>idioma: <input name="idioma" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>