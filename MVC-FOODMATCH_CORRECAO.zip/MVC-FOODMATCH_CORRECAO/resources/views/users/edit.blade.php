<div>
<h2>Editar</h2>
<form action="/users/{{ $user->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>name: <input name="name" value="{{ old("name", $user->name ?? "") }}" /></label><br>
<label>email: <input name="email" value="{{ old("email", $user->email ?? "") }}" /></label><br>
<label>password: <input name="password" value="{{ old("password", $user->password ?? "") }}" /></label><br>
<label>idioma: <input name="idioma" value="{{ old("idioma", $user->idioma ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/users/{{ $user->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>