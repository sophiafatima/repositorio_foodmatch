<div>
<h2>Users</h2>
<a href="/users/create">Criar</a>
<ul>
@foreach ($users as $item)
<li><a href="/users/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>