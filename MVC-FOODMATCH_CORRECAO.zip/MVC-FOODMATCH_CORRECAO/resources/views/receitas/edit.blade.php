<div>
<h2>Editar</h2>
<form action="/receitas/{{ $receita->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>nome_receita: <input name="nome_receita" value="{{ old("nome_receita", $receita->nome_receita ?? "") }}" /></label><br>
<label>preferencias: <input name="preferencias" value="{{ old("preferencias", $receita->preferencias ?? "") }}" /></label><br>
<label>restricao: <input name="restricao" value="{{ old("restricao", $receita->restricao ?? "") }}" /></label><br>
<label>ingredientes: <input name="ingredientes" value="{{ old("ingredientes", $receita->ingredientes ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/receitas/{{ $receita->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>