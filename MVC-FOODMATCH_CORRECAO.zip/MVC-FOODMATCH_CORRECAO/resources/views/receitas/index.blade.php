<div>
<h2>Receitas</h2>
<a href="/receitas/create">Criar</a>
<ul>
@foreach ($receitas as $item)
<li><a href="/receitas/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>