<div>
<h2>Detalhe</h2>
@foreach($receita->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/receitas/{{ $receita->getKey() }}/edit">Editar</a>
</div>