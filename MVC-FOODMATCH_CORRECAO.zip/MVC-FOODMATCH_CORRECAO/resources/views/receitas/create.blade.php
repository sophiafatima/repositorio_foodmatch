<div>
<h2>Novo em Receitas</h2>
<form action="/receitas" method="POST">
@csrf
<label>nome_receita: <input name="nome_receita" /></label><br>
<label>preferencias: <input name="preferencias" /></label><br>
<label>restricao: <input name="restricao" /></label><br>
<label>ingredientes: <input name="ingredientes" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>