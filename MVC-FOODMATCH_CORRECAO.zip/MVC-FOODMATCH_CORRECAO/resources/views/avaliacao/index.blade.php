<div>
   Avaliacao
<div>
@if ($avaliacoes)
@foreach ($avaliacoes as $avaliacao)
<div>
<p>
{{ $avaliacao->name }}
</p>
<p>
Nota: {{ $restaurant->rating }}
</p>
<p>
Categoria: {{ $restaurant->type }}
</p>
</div>
@endforeach
@endif
</div>
</div>
<div>
    <h2>Avaliações</h2>
    @if ($avaliacoes->count())
        @foreach ($avaliacoes as $avaliacao)
            <div>
                <p>Usuário: {{ $avaliacao->nome_usuario }}</p>
                <p>Receita: {{ $avaliacao->nome_receita }}</p>
                <p>Nota: {{ $avaliacao->nota }}</p>
                <p>Comentário: {{ $avaliacao->comentario }}</p>
            </div>
        @endforeach
    @else
        <p>Nenhuma avaliação encontrada.</p>
    @endif
</div>