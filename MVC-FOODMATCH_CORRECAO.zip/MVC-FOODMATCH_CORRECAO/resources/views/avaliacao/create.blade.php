<div>
    <form method="POST" action="{{ route('avaliacoes.store') }}">
        @csrf
        <input name="id_usuario" placeholder="ID do usuário" />
        <input name="nome_receita" placeholder="Nome da receita" />
        <input name="nota" placeholder="Nota" type="number" step="0.1" />
        <input name="comentario" placeholder="Comentário" />
        <input name="nome_usuario" placeholder="Nome do usuário" />
        <button type="submit">Criar avaliação</button>
    </form>
</div>