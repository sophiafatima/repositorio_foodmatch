<div>
<h2>Novo em Receitas_Salvas</h2>
<form action="/receitas_salvas" method="POST">
@csrf
<label>id_receita: <input name="id_receita" /></label><br>
<label>id_usuario: <input name="id_usuario" /></label><br>
<label>nome_usuario: <input name="nome_usuario" /></label><br>
<label>descricao_receita: <input name="descricao_receita" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>