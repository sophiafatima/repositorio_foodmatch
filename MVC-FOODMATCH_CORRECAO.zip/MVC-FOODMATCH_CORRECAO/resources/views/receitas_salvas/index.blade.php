<div>
<h2>Receitas_Salvas</h2>
<a href="/receitas_salvas/create">Criar</a>
<ul>
@foreach ($receitas as $item)
<li><a href="/receitas_salvas/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>