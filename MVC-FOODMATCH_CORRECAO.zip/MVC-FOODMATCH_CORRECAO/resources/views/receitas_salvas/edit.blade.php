<div>
<h2>Editar</h2>
<form action="/receitas_salvas/{{ $item->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>id_receita: <input name="id_receita" value="{{ old("id_receita", $item->id_receita ?? "") }}" /></label><br>
<label>id_usuario: <input name="id_usuario" value="{{ old("id_usuario", $item->id_usuario ?? "") }}" /></label><br>
<label>nome_usuario: <input name="nome_usuario" value="{{ old("nome_usuario", $item->nome_usuario ?? "") }}" /></label><br>
<label>descricao_receita: <input name="descricao_receita" value="{{ old("descricao_receita", $item->descricao_receita ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/receitas_salvas/{{ $item->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>