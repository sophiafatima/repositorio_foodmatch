<div>
<h2>Detalhe</h2>
@foreach($item->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/receitas_salvas/{{ $item->getKey() }}/edit">Editar</a>
</div>