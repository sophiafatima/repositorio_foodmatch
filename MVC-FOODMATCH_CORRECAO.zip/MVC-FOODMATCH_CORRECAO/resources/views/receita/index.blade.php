<div>
    <h2>Receitas</h2>
    @if ($receitas->count())
        @foreach ($receitas as $receita)
            <div>
                <p>Nome: {{ $receita->nome_receita }}</p>
                <p>Preferências: {{ $receita->preferencias }}</p>
                <p>Restrições: {{ $receita->restricao }}</p>
                <p>Ingredientes: {{ $receita->ingredientes }}</p>
            </div>
        @endforeach
    @else
        <p>Nenhuma receita encontrada.</p>
    @endif
</div>