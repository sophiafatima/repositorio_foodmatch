<div>
    <form method="POST" action="{{ route('receitas.store') }}">
        @csrf
        <input name="nome_receita" placeholder="Nome da receita" />
        <input name="preferencias" placeholder="Preferências" />
        <input name="restricao" placeholder="Restrições" />
        <textarea name="ingredientes" placeholder="Ingredientes"></textarea>
        <button type="submit">Criar receita</button>
    </form>
</div>