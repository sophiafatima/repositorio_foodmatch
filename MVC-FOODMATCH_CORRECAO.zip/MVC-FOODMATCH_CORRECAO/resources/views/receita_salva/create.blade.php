<div>
    <form method="POST" action="{{ route('receitas_salvas.store') }}">
        @csrf
        <input name="id_receita" placeholder="ID da receita" />
        <input name="id_usuario" placeholder="ID do usuário" />
        <input name="nome_usuario" placeholder="Nome do usuário" />
        <input name="descricao_receita" placeholder="Descrição da receita" />
        <button type="submit">Salvar receita</button>
    </form>
</div>