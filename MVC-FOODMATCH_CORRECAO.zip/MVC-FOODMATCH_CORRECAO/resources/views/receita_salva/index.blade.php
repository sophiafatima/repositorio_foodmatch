<div>
    <h2>Receitas Salvas</h2>
    @if ($receitasSalvas->count())
        @foreach ($receitasSalvas as $receita)
            <div>
                <p>Usuário: {{ $receita->nome_usuario }}</p>
                <p>Receita ID: {{ $receita->id_receita }}</p>
                <p>Descrição: {{ $receita->descricao_receita }}</p>
            </div>
        @endforeach
    @else
        <p>Nenhuma receita salva encontrada.</p>
    @endif
</div>