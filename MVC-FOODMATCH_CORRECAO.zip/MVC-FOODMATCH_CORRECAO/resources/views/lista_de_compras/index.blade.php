<div>
<h2>Lista_De_Compras</h2>
<a href="/lista_de_compras/create">Criar</a>
<ul>
@foreach ($listas as $item)
<li><a href="/lista_de_compras/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>