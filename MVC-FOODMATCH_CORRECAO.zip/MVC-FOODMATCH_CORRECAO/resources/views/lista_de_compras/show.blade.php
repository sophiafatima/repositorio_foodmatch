<div>
<h2>Detalhe</h2>
@foreach($lista->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/lista_de_compras/{{ $lista->getKey() }}/edit">Editar</a>
</div>