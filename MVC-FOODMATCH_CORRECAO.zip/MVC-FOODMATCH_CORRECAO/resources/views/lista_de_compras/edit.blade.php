<div>
<h2>Editar</h2>
<form action="/lista_de_compras/{{ $lista->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>id_receita: <input name="id_receita" value="{{ old("id_receita", $lista->id_receita ?? "") }}" /></label><br>
<label>recomendacao: <input name="recomendacao" value="{{ old("recomendacao", $lista->recomendacao ?? "") }}" /></label><br>
<label>ingredientes: <input name="ingredientes" value="{{ old("ingredientes", $lista->ingredientes ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/lista_de_compras/{{ $lista->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>