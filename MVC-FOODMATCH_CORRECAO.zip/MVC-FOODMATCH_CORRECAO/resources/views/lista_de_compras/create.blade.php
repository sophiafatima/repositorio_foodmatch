<div>
<h2>Novo em Lista_De_Compras</h2>
<form action="/lista_de_compras" method="POST">
@csrf
<label>id_receita: <input name="id_receita" /></label><br>
<label>recomendacao: <input name="recomendacao" /></label><br>
<label>ingredientes: <input name="ingredientes" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>