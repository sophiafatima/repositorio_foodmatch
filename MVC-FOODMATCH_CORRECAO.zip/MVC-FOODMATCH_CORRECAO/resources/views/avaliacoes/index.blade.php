<div>
<h2>Avaliacoes</h2>
<a href="/avaliacoes/create">Criar</a>
<ul>
@foreach ($avaliacoes as $item)
<li><a href="/avaliacoes/{ $item->getKey() }">#{ $item->getKey() }</a></li>
@endforeach
</ul>
</div>