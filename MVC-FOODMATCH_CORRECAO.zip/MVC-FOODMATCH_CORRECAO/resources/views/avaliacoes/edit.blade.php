<div>
<h2>Editar</h2>
<form action="/avaliacoes/{{ $avaliacao->getKey() }}" method="POST">
@csrf
@method('PUT')
<label>id_usuario: <input name="id_usuario" value="{{ old("id_usuario", $avaliacao->id_usuario ?? "") }}" /></label><br>
<label>nome_receita: <input name="nome_receita" value="{{ old("nome_receita", $avaliacao->nome_receita ?? "") }}" /></label><br>
<label>nota: <input name="nota" value="{{ old("nota", $avaliacao->nota ?? "") }}" /></label><br>
<label>comentario: <input name="comentario" value="{{ old("comentario", $avaliacao->comentario ?? "") }}" /></label><br>
<label>nome_usuario: <input name="nome_usuario" value="{{ old("nome_usuario", $avaliacao->nome_usuario ?? "") }}" /></label><br>
<button type="submit">Atualizar</button>
</form>
<form action="/avaliacoes/{{ $avaliacao->getKey() }}" method="POST" onsubmit="return confirm('Excluir?')">
@csrf
@method('DELETE')
<button type="submit">Excluir</button>
</form>
</div>