<div>
<h2>Detalhe</h2>
@foreach($avaliacao->getAttributes() as $k=>$v)
<p>{{ $k }}: {{ $v }}</p>
@endforeach
<a href="/avaliacoes/{{ $avaliacao->getKey() }}/edit">Editar</a>
</div>