<div>
<h2>Novo em Avaliacoes</h2>
<form action="/avaliacoes" method="POST">
@csrf
<label>id_usuario: <input name="id_usuario" /></label><br>
<label>nome_receita: <input name="nome_receita" /></label><br>
<label>nota: <input name="nota" /></label><br>
<label>comentario: <input name="comentario" /></label><br>
<label>nome_usuario: <input name="nome_usuario" /></label><br>
<button type="submit">Salvar</button>
</form>
</div>