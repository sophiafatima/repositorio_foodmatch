<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReceitaSalva extends Model
{
    protected $table = 'receitas_salvas';
    protected $primaryKey = 'id_salva';
    public $timestamps = true;

    protected $fillable = [
        'id_receita', 'id_usuario', 'nome_usuario', 'descricao_receita'
    ];
}
