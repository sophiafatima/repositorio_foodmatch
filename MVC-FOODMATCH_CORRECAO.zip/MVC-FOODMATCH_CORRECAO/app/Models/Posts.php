<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Posts extends Model
{
   protected $table = "posts";
    protected $primaryKey = "id_post";
    protected $fillable = [
        "id_usuario", "titulo_post", "descricao_post"];
}
