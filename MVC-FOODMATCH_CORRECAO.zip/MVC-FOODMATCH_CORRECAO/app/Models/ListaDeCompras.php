<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ListaDeCompras extends Model
{
    protected $table = 'lista_de_compras';
    protected $primaryKey = 'id_lista';
    public $timestamps = true;

    protected $fillable = [
        'id_receita', 'recomendacao', 'ingredientes'
    ];
}
