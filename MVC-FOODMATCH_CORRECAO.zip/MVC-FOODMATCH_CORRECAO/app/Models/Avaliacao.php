<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Avaliacao extends Model
{
    protected $table = 'avaliacao';
    protected $primaryKey = 'id_avaliacao';
    public $timestamps = true;

    protected $fillable = [
        'id_usuario', 'nome_receita', 'nota', 'comentario', 'nome_usuario'
    ];
}
