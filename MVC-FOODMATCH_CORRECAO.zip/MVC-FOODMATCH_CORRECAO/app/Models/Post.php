<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = 'posts';
    protected $primaryKey = 'id_post';
    public $timestamps = true;

    protected $fillable = [
        'id_usuario', 'titulo_post', 'descricao_post'
    ];
}
