<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Receita extends Model
{
    protected $table = 'receitas';
    protected $primaryKey = 'id_receita';
    public $timestamps = true;

    protected $fillable = [
        'nome_receita', 'preferencias', 'restricao', 'ingredientes'
    ];
}
