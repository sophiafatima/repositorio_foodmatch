<?php
namespace App\Http\Controllers;

use App\Models\Avaliacao;
use Illuminate\Http\Request;

class AvaliacaoController extends Controller
{
    public function index()
    {
        $avaliacoes = Avaliacao::latest()->get();
        return view('avaliacoes.index', compact('avaliacoes'));
    }

    public function create()
    {
        return view('avaliacoes.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_usuario' => 'required|integer',
            'nome_receita' => 'required|string|max:255',
            'nota' => 'required|numeric|min:0|max:5',
            'comentario' => 'nullable|string',
            'nome_usuario' => 'required|string|max:255',
        ]);
        $avaliacao = Avaliacao::create($data);
        return redirect()->route('avaliacoes.show', $avaliacao->id_avaliacao);
    }

    public function show($id)
    {
        $avaliacao = Avaliacao::findOrFail($id);
        return view('avaliacoes.show', compact('avaliacao'));
    }

    public function edit($id)
    {
        $avaliacao = Avaliacao::findOrFail($id);
        return view('avaliacoes.edit', compact('avaliacao'));
    }

    public function update(Request $request, $id)
    {
        $avaliacao = Avaliacao::findOrFail($id);
        $data = $request->validate([
            'id_usuario' => 'required|integer',
            'nome_receita' => 'required|string|max:255',
            'nota' => 'required|numeric|min:0|max:5',
            'comentario' => 'nullable|string',
            'nome_usuario' => 'required|string|max:255',
        ]);
        $avaliacao->update($data);
        return redirect()->route('avaliacoes.show', $avaliacao->id_avaliacao);
    }

    public function destroy($id)
    {
        Avaliacao::destroy($id);
        return redirect()->route('avaliacoes.index');
    }
}
