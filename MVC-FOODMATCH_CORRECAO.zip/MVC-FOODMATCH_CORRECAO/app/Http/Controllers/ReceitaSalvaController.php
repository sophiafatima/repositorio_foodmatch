<?php
namespace App\Http\Controllers;

use App\Models\ReceitaSalva;
use Illuminate\Http\Request;

class ReceitaSalvaController extends Controller
{
    public function index()
    {
        $receitas = ReceitaSalva::latest()->get();
        return view('receitas_salvas.index', compact('receitas'));
    }

    public function create()
    {
        return view('receitas_salvas.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_receita' => 'required|integer',
            'id_usuario' => 'required|integer',
            'nome_usuario' => 'required|string|max:255',
            'descricao_receita' => 'nullable|string',
        ]);
        $item = ReceitaSalva::create($data);
        return redirect()->route('receitas_salvas.show', $item->id_salva);
    }

    public function show($id)
    {
        $item = ReceitaSalva::findOrFail($id);
        return view('receitas_salvas.show', compact('item'));
    }

    public function edit($id)
    {
        $item = ReceitaSalva::findOrFail($id);
        return view('receitas_salvas.edit', compact('item'));
    }

    public function update(Request $request, $id)
    {
        $item = ReceitaSalva::findOrFail($id);
        $data = $request->validate([
            'id_receita' => 'required|integer',
            'id_usuario' => 'required|integer',
            'nome_usuario' => 'required|string|max:255',
            'descricao_receita' => 'nullable|string',
        ]);
        $item->update($data);
        return redirect()->route('receitas_salvas.show', $item->id_salva);
    }

    public function destroy($id)
    {
        ReceitaSalva::destroy($id);
        return redirect()->route('receitas_salvas.index');
    }
}
