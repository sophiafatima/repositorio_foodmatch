<?php
namespace App\Http\Controllers;

use App\Models\Empresa;
use Illuminate\Http\Request;

class EmpresaController extends Controller
{
    public function index()
    {
        $empresas = Empresa::latest()->get();
        return view('empresa.index', compact('empresas'));
    }

    public function create()
    {
        return view('empresa.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nome_empresa' => 'required|string|max:255',
            'email_empresa' => 'required|email|unique:empresas,email_empresa',
            'senha_empresa' => 'required|string|min:6',
        ]);
        $empresa = Empresa::create($data);
        return redirect()->route('empresa.show', $empresa->id_empresa);
    }

    public function show($id)
    {
        $empresa = Empresa::findOrFail($id);
        return view('empresa.show', compact('empresa'));
    }

    public function edit($id)
    {
        $empresa = Empresa::findOrFail($id);
        return view('empresa.edit', compact('empresa'));
    }

    public function update(Request $request, $id)
    {
        $empresa = Empresa::findOrFail($id);
        $data = $request->validate([
            'nome_empresa' => 'required|string|max:255',
            'email_empresa' => 'required|email|unique:empresas,email_empresa,' . $empresa->id_empresa . ',id_empresa',
            'senha_empresa' => 'nullable|string|min:6',
        ]);
        $empresa->update($data);
        return redirect()->route('empresa.show', $empresa->id_empresa);
    }

    public function destroy($id)
    {
        Empresa::destroy($id);
        return redirect()->route('empresa.index');
    }
}
