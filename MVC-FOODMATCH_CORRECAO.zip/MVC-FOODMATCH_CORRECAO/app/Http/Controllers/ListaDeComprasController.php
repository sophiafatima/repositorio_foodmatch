<?php
namespace App\Http\Controllers;

use App\Models\ListaDeCompras;
use Illuminate\Http\Request;

class ListaDeComprasController extends Controller
{
    public function index()
    {
        $listas = ListaDeCompras::latest()->get();
        return view('lista_de_compras.index', compact('listas'));
    }

    public function create()
    {
        return view('lista_de_compras.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_receita' => 'required|integer',
            'recomendacao' => 'nullable|string',
            'ingredientes' => 'nullable|string',
        ]);
        $lista = ListaDeCompras::create($data);
        return redirect()->route('lista_de_compras.show', $lista->id_lista);
    }

    public function show($id)
    {
        $lista = ListaDeCompras::findOrFail($id);
        return view('lista_de_compras.show', compact('lista'));
    }

    public function edit($id)
    {
        $lista = ListaDeCompras::findOrFail($id);
        return view('lista_de_compras.edit', compact('lista'));
    }

    public function update(Request $request, $id)
    {
        $lista = ListaDeCompras::findOrFail($id);
        $data = $request->validate([
            'id_receita' => 'required|integer',
            'recomendacao' => 'nullable|string',
            'ingredientes' => 'nullable|string',
        ]);
        $lista->update($data);
        return redirect()->route('lista_de_compras.show', $lista->id_lista);
    }

    public function destroy($id)
    {
        ListaDeCompras::destroy($id);
        return redirect()->route('lista_de_compras.index');
    }
}
