<?php
namespace App\Http\Controllers;

use App\Models\Receita;
use Illuminate\Http\Request;

class ReceitaController extends Controller
{
    public function index()
    {
        $receitas = Receita::latest()->get();
        return view('receitas.index', compact('receitas'));
    }

    public function create()
    {
        return view('receitas.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nome_receita' => 'required|string|max:255',
            'preferencias' => 'nullable|string',
            'restricao' => 'nullable|string',
            'ingredientes' => 'nullable|string',
        ]);
        $r = Receita::create($data);
        return redirect()->route('receitas.show', $r->id_receita);
    }

    public function show($id)
    {
        $receita = Receita::findOrFail($id);
        return view('receitas.show', compact('receita'));
    }

    public function edit($id)
    {
        $receita = Receita::findOrFail($id);
        return view('receitas.edit', compact('receita'));
    }

    public function update(Request $request, $id)
    {
        $receita = Receita::findOrFail($id);
        $data = $request->validate([
            'nome_receita' => 'required|string|max:255',
            'preferencias' => 'nullable|string',
            'restricao' => 'nullable|string',
            'ingredientes' => 'nullable|string',
        ]);
        $receita->update($data);
        return redirect()->route('receitas.show', $receita->id_receita);
    }

    public function destroy($id)
    {
        Receita::destroy($id);
        return redirect()->route('receitas.index');
    }
}
