<?php

namespace App\Http\Controllers;

use App\Models\ListaCompras;
use Illuminate\Http\Request;

class ListaComprasController extends Controller
{
    public function index()
    {
        $listas = ListaCompras::all();
        return view('listas.index', compact('listas'));
    }

    public function create()
    {
        return view('listas.create');
    }

    public function store(Request $request)
    {
        ListaCompras::create($request->all());
        return redirect()->route('listas.index');
    }

    public function show($id)
    {
        $lista = ListaCompras::findOrFail($id);
        return view('listas.show', compact('lista'));
    }

    public function destroy($id)
    {
        ListaCompras::destroy($id);
        return redirect()->route('listas.index');
    }
}
