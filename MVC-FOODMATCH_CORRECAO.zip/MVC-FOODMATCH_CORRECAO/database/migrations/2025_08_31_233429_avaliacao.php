<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('avaliacao', function (Blueprint $table) {
            $table->id('id_avaliacao'); 
            $table->foreignId('id_usuario')->constrained('users'); 
            $table->string('nome_receita');
            $table->decimal('nota', 5, 2);
            $table->string('comentario');
            $table->string('nome_usuario');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('avaliacao');
    }
};