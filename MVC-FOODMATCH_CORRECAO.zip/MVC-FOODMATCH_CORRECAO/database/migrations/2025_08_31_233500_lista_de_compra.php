<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lista_de_compras', function (Blueprint $table) {
            $table->id('id_lista');
            $table->foreignId('id_receita')->constrained('receitas')->onDelete('cascade');
            $table->string('recomendacao')->nullable();
            $table->text('ingredientes');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lista_de_compras');
    }
};
