<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UsersTableSeeder::class,
            EmpresasTableSeeder::class,
            ReceitasTableSeeder::class,
            AvaliacaoTableSeeder::class,
            ReceitasSalvasTableSeeder::class,
            ListaDeComprasTableSeeder::class,
            PostsTableSeeder::class,
        ]);
    }
}