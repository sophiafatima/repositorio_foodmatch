<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AvaliacaoController;
use App\Http\Controllers\ListaDeComprasController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\ReceitaController;
use App\Http\Controllers\ReceitaSalvaController;
use App\Http\Controllers\EmpresaController;

Route::redirect('/', '/users');

Route::resource('users', UserController::class);
Route::resource('avaliacoes', AvaliacaoController::class);
Route::resource('lista_de_compras', ListaDeComprasController::class);
Route::resource('posts', PostController::class);
Route::resource('receitas', ReceitaController::class);
Route::resource('receitas_salvas', ReceitaSalvaController::class);
Route::resource('empresa', EmpresaController::class);
